# Replit.md

## Overview

This is an AI-powered internship matching system built for the PM Internship Scheme in India. The application helps young candidates from diverse backgrounds find relevant internship opportunities by analyzing their profiles and matching them with suitable positions. It features an intelligent filtering system that considers education level, skills, location preferences, and sector interests to provide personalized recommendations.

The system processes a comprehensive dataset of internships and uses Google's Gemini AI to provide explanations for matches and enhance the matching algorithm. It supports both English and Hindi languages to cater to India's diverse population.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom design system variables
- **State Management**: React Query (TanStack Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Handling**: React Hook Form with Zod validation

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API with structured endpoints
- **Data Processing**: CSV parsing for internship and location data
- **Matching Algorithm**: Rule-based scoring system with weighted criteria
- **Storage**: In-memory storage with interface for future database integration

### Data Storage Solutions
- **Current**: In-memory storage using Map data structures
- **Schema**: Drizzle ORM schema definitions with PostgreSQL dialect
- **Database Ready**: Configured for Neon Database with connection pooling
- **Data Sources**: CSV files for skills, locations, and internship data

### Authentication and Authorization
- **Current**: No authentication implemented (suitable for MVP/hackathon)
- **Schema Ready**: User table defined in database schema
- **Session Management**: Connect-pg-simple configured for PostgreSQL sessions

### Matching Engine
- **Algorithm**: Multi-criteria matching with weighted scoring
  - Education level compatibility (20% weight)
  - Skills overlap analysis (40% weight)
  - Location preference matching (25% weight)
  - Sector interest alignment (15% weight)
- **AI Enhancement**: Gemini AI integration for match explanations
- **Scoring**: Percentage-based scoring with top match identification
- **Filtering**: Rule-based filtering before AI analysis

### Component Architecture
- **Form Components**: Multi-step candidate profile creation with validation
- **Loading States**: Animated loading screens with progress indication
- **Results Display**: Paginated results with filtering capabilities
- **Responsive Design**: Mobile-first approach with adaptive layouts

## External Dependencies

### Third-party Services
- **Google Gemini AI**: Content generation and sentiment analysis using @google/genai
- **Neon Database**: PostgreSQL database service via @neondatabase/serverless

### UI and Design Libraries
- **Radix UI**: Comprehensive set of accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework with custom configuration
- **Lucide React**: Icon library for consistent iconography

### Development Tools
- **Vite**: Modern build tool with hot module replacement
- **Drizzle ORM**: Type-safe database toolkit with schema management
- **Zod**: Runtime type validation and schema definition
- **ESBuild**: Fast JavaScript bundler for production builds

### Data Processing
- **CSV Parsing**: Custom CSV loader for skills and locations data
- **Date Handling**: date-fns library for date manipulation
- **Query Client**: TanStack Query for efficient data fetching and caching

### Translation Support
- **Internationalization**: Built-in translation service supporting English and Hindi
- **Language Switching**: Dynamic language switching with persistent state
- **Localized UI**: All user-facing text with translation keys