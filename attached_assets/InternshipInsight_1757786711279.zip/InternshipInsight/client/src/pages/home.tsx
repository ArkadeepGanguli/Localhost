import { useState } from "react";
import { CandidateForm } from "@/components/candidate-form";
import { LoadingScreen } from "@/components/loading-screen";
import { RecommendationResults } from "@/components/recommendation-results";
import { Button } from "@/components/ui/button";
import { GraduationCap, Languages, User } from "lucide-react";
import { useFindMatches, type MatchingResult } from "@/hooks/use-internship-matching";
import type { CandidateFormData } from "@shared/schema";

type AppState = "form" | "loading" | "results";

export default function Home() {
  const [appState, setAppState] = useState<AppState>("form");
  const [language, setLanguage] = useState<"en" | "hi">("en");
  const [progress, setProgress] = useState(33);
  const [matches, setMatches] = useState<MatchingResult[]>([]);
  const [candidateData, setCandidateData] = useState<CandidateFormData | null>(null);
  const [allMatches, setAllMatches] = useState<MatchingResult[]>([]);
  const [displayedMatches, setDisplayedMatches] = useState(5);
  const [hasMore, setHasMore] = useState(false);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [filterHighMatch, setFilterHighMatch] = useState(false);

  const findMatches = useFindMatches();

  // Helper function to get filtered matches
  const getFilteredMatches = (allResults: MatchingResult[], filterHigh: boolean) => {
    return filterHigh ? allResults.filter(match => match.matchScore >= 90) : allResults;
  };

  // Helper function to update matches based on current filter and pagination
  const updateDisplayedMatches = (allResults: MatchingResult[], filterHigh: boolean, displayed: number) => {
    const filtered = getFilteredMatches(allResults, filterHigh);
    const toShow = filtered.slice(0, displayed);
    setMatches(toShow);
    setHasMore(filtered.length > displayed);
  };

  const toggleLanguage = () => {
    setLanguage(language === "en" ? "hi" : "en");
  };

  const handleFilterChange = (newFilterState: boolean) => {
    setFilterHighMatch(newFilterState);
    // Reset pagination when filter changes
    setDisplayedMatches(5);
    setIsLoadingMore(false);
    updateDisplayedMatches(allMatches, newFilterState, 5);
  };

  const handleLoadMore = () => {
    setIsLoadingMore(true);
    
    // Simulate loading time
    setTimeout(() => {
      const newDisplayedCount = displayedMatches + 5;
      setDisplayedMatches(newDisplayedCount);
      updateDisplayedMatches(allMatches, filterHighMatch, newDisplayedCount);
      setIsLoadingMore(false);
    }, 1000);
  };

  const handleFormSubmit = async (data: CandidateFormData & { candidateId: string }) => {
    setCandidateData(data);
    setAppState("loading");
    setProgress(66);

    try {
      const result = await findMatches.mutateAsync(data.candidateId);
      setAllMatches(result.matches);
      
      // Reset pagination and filter state for new search
      setDisplayedMatches(5);
      setFilterHighMatch(false);
      setIsLoadingMore(false);
      updateDisplayedMatches(result.matches, false, 5);
      
      // Simulate processing time
      setTimeout(() => {
        setAppState("results");
        setProgress(100);
      }, 4500);
    } catch (error) {
      console.error("Error finding matches:", error);
      // Handle error - maybe show error state
      setAppState("form");
      setProgress(33);
    }
  };

  const getStepText = () => {
    const steps = {
      en: {
        form: { step: "Step 1 of 3", title: "Profile Setup" },
        loading: { step: "Step 2 of 3", title: "AI Analysis" },
        results: { step: "Step 3 of 3", title: "Recommendations Ready" },
      },
      hi: {
        form: { step: "चरण 1 का 3", title: "प्रोफाइल सेटअप" },
        loading: { step: "चरण 2 का 3", title: "AI विश्लेषण" },
        results: { step: "चरण 3 का 3", title: "सिफारिशें तैयार" },
      }
    };
    return steps[language][appState];
  };

  const stepInfo = getStepText();

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="glass-effect border-b border-border sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <GraduationCap className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-foreground">
                  PM Internship Scheme
                </h1>
                <p className="text-sm text-muted-foreground">
                  {language === "en" ? "Smart Matching Platform" : "स्मार्ट मैचिंग प्लेटफॉर्म"}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="secondary"
                size="sm"
                onClick={toggleLanguage}
                className="flex items-center space-x-2"
                data-testid="button-language-toggle"
              >
                <Languages className="h-4 w-4" />
                <span className="font-medium">{language.toUpperCase()}</span>
              </Button>
              <Button variant="ghost" size="sm">
                <User className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
            <span data-testid="progress-step">{stepInfo.step}</span>
            <span data-testid="progress-title">{stepInfo.title}</span>
          </div>
          <div className="w-full bg-secondary rounded-full h-2">
            <div 
              className="bg-primary h-2 rounded-full transition-all duration-500"
              style={{ width: `${progress}%` }}
              data-testid="progress-bar"
            />
          </div>
        </div>

        {/* Content based on state */}
        {appState === "form" && (
          <CandidateForm onSubmit={handleFormSubmit} language={language} />
        )}

        {appState === "loading" && (
          <LoadingScreen language={language} />
        )}

        {appState === "results" && (
          <RecommendationResults 
            matches={matches} 
            allMatches={allMatches}
            language={language}
            onLoadMore={handleLoadMore}
            hasMore={hasMore}
            isLoadingMore={isLoadingMore}
            filterHighMatch={filterHighMatch}
            onFilterChange={handleFilterChange}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-muted/50 border-t border-border mt-12">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h4 className="font-semibold text-foreground mb-4">PM Internship Scheme</h4>
              <p className="text-sm text-muted-foreground">
                {language === "en" 
                  ? "Empowering India's youth with meaningful internship opportunities."
                  : "भारत के युवाओं को सार्थक इंटर्नशिप अवसरों के साथ सशक्त बनाना।"
                }
              </p>
            </div>
            <div>
              <h5 className="font-medium text-foreground mb-3">
                {language === "en" ? "Quick Links" : "त्वरित लिंक"}
              </h5>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">
                  {language === "en" ? "About the Scheme" : "योजना के बारे में"}
                </a></li>
                <li><a href="#" className="hover:text-foreground">
                  {language === "en" ? "Eligibility" : "पात्रता"}
                </a></li>
                <li><a href="#" className="hover:text-foreground">
                  {language === "en" ? "Application Process" : "आवेदन प्रक्रिया"}
                </a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-foreground mb-3">
                {language === "en" ? "Support" : "सहायता"}
              </h5>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">
                  {language === "en" ? "Help Center" : "सहायता केंद्र"}
                </a></li>
                <li><a href="#" className="hover:text-foreground">
                  {language === "en" ? "Contact Us" : "संपर्क करें"}
                </a></li>
                <li><a href="#" className="hover:text-foreground">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-medium text-foreground mb-3">
                {language === "en" ? "Legal" : "कानूनी"}
              </h5>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><a href="#" className="hover:text-foreground">
                  {language === "en" ? "Privacy Policy" : "गोपनीयता नीति"}
                </a></li>
                <li><a href="#" className="hover:text-foreground">
                  {language === "en" ? "Terms of Service" : "सेवा की शर्तें"}
                </a></li>
                <li><a href="#" className="hover:text-foreground">
                  {language === "en" ? "Guidelines" : "दिशानिर्देश"}
                </a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-border mt-8 pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2024 Government of India. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
