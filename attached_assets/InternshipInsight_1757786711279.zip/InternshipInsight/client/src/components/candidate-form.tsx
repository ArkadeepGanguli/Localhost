import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { MultiSelect } from "@/components/ui/multi-select";
import { candidateFormSchema, type CandidateFormData } from "@shared/schema";
import { useSkills, useLocations, useCreateCandidate } from "@/hooks/use-internship-matching";
import { Loader2, GraduationCap } from "lucide-react";

interface CandidateFormProps {
  onSubmit: (data: CandidateFormData & { candidateId: string }) => void;
  language: "en" | "hi";
}

const SECTOR_OPTIONS = [
  "Technology",
  "Marketing", 
  "Finance",
  "Design",
  "Sales",
  "Operations",
  "Healthcare",
  "Education",
  "Manufacturing",
  "Consulting"
];

const EDUCATION_OPTIONS = [
  { value: "high-school", label: "High School (12th Grade)" },
  { value: "diploma", label: "Diploma" },
  { value: "bachelors", label: "Bachelor's Degree" },
  { value: "masters", label: "Master's Degree" },
  { value: "phd", label: "PhD" },
];

const translations = {
  en: {
    title: "Tell us about yourself",
    subtitle: "Help us find the perfect internship opportunities for you",
    fullName: "Full Name",
    email: "Email Address",
    educationLevel: "Education Level",
    selectEducation: "Select your education level",
    skills: "Skills & Expertise",
    sectorInterests: "Sector Interests",
    locationPreferences: "Location Preferences",
    findMatches: "Find My Matches",
    processing: "Processing...",
  },
  hi: {
    title: "अपने बारे में बताएं",
    subtitle: "हमें आपके लिए सही इंटर्नशिप अवसर खोजने में मदद करें",
    fullName: "पूरा नाम",
    email: "ईमेल पता", 
    educationLevel: "शिक्षा स्तर",
    selectEducation: "अपना शिक्षा स्तर चुनें",
    skills: "कौशल और विशेषज्ञता",
    sectorInterests: "क्षेत्र रुचियां",
    locationPreferences: "स्थान प्राथमिकताएं",
    findMatches: "मेरे मैच खोजें",
    processing: "प्रसंस्करण...",
  }
};

export function CandidateForm({ onSubmit, language }: CandidateFormProps) {
  const t = translations[language];
  const { data: skills = [], isLoading: skillsLoading } = useSkills();
  const { data: locations = [], isLoading: locationsLoading } = useLocations();
  const createCandidate = useCreateCandidate();

  const form = useForm<CandidateFormData>({
    resolver: zodResolver(candidateFormSchema),
    defaultValues: {
      fullName: "",
      email: "",
      educationLevel: "bachelors",
      skills: [],
      sectorInterests: [],
      locationPreferences: [],
      languagePreference: language,
    },
  });

  const handleSubmit = async (data: CandidateFormData) => {
    try {
      const result = await createCandidate.mutateAsync(data);
      onSubmit({
        ...data,
        candidateId: result.candidate.id,
      });
    } catch (error) {
      console.error("Error creating candidate:", error);
    }
  };

  return (
    <Card className="animate-fade-in">
      <CardHeader className="text-center">
        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
          <GraduationCap className="h-8 w-8 text-primary" />
        </div>
        <CardTitle className="text-2xl font-semibold">{t.title}</CardTitle>
        <p className="text-muted-foreground">{t.subtitle}</p>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            {/* Basic Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="fullName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t.fullName}</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Enter your full name"
                        {...field}
                        data-testid="input-full-name"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t.email}</FormLabel>
                    <FormControl>
                      <Input
                        type="email"
                        placeholder="your.email@domain.com"
                        {...field}
                        data-testid="input-email"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Education Level */}
            <FormField
              control={form.control}
              name="educationLevel"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t.educationLevel}</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger data-testid="select-education">
                        <SelectValue placeholder={t.selectEducation} />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {EDUCATION_OPTIONS.map((option) => (
                        <SelectItem 
                          key={option.value} 
                          value={option.value}
                          data-testid={`education-option-${option.value}`}
                        >
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Skills */}
            <FormField
              control={form.control}
              name="skills"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t.skills}</FormLabel>
                  <FormControl>
                    <MultiSelect
                      options={skills}
                      selected={field.value}
                      onChange={field.onChange}
                      placeholder="Search and select your skills..."
                      data-testid="multi-select-skills"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Sector Interests */}
            <FormField
              control={form.control}
              name="sectorInterests"
              render={() => (
                <FormItem>
                  <FormLabel>{t.sectorInterests}</FormLabel>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {SECTOR_OPTIONS.map((sector) => (
                      <FormField
                        key={sector}
                        control={form.control}
                        name="sectorInterests"
                        render={({ field }) => {
                          return (
                            <FormItem
                              key={sector}
                              className="flex flex-row items-start space-x-3 space-y-0"
                            >
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(sector)}
                                  onCheckedChange={(checked) => {
                                    return checked
                                      ? field.onChange([...field.value, sector])
                                      : field.onChange(
                                          field.value?.filter(
                                            (value) => value !== sector
                                          )
                                        )
                                  }}
                                  data-testid={`checkbox-sector-${sector.toLowerCase().replace(/\s+/g, '-')}`}
                                />
                              </FormControl>
                              <FormLabel className="text-sm font-normal">
                                {sector}
                              </FormLabel>
                            </FormItem>
                          );
                        }}
                      />
                    ))}
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Location Preferences */}
            <FormField
              control={form.control}
              name="locationPreferences"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>{t.locationPreferences}</FormLabel>
                  
                  {/* Quick Options */}
                  <div className="flex flex-wrap gap-4 mb-3">
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value?.includes("Any")}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              field.onChange(["Any"]);
                            } else {
                              field.onChange(field.value?.filter(val => val !== "Any") || []);
                            }
                          }}
                          data-testid="checkbox-location-any"
                        />
                      </FormControl>
                      <FormLabel className="text-sm font-normal">
                        Any Location
                      </FormLabel>
                    </FormItem>
                    
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value?.includes("Remote")}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              // Remote is mutually exclusive with Any and Specific Locations
                              field.onChange(["Remote"]);
                            } else {
                              field.onChange(field.value?.filter(val => val !== "Remote") || []);
                            }
                          }}
                          data-testid="checkbox-location-remote"
                        />
                      </FormControl>
                      <FormLabel className="text-sm font-normal">
                        Remote Work
                      </FormLabel>
                    </FormItem>
                    
                    <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value?.includes("SpecificLocations")}
                          onCheckedChange={(checked) => {
                            if (checked) {
                              // Specific Locations is mutually exclusive with Any and Remote
                              field.onChange(["SpecificLocations"]);
                            } else {
                              // Remove SpecificLocations and all city values, keep only Any/Remote if present
                              const cleanValue = field.value?.filter(val => ["Any", "Remote"].includes(val)) || [];
                              field.onChange(cleanValue);
                            }
                          }}
                          data-testid="checkbox-location-specific"
                        />
                      </FormControl>
                      <FormLabel className="text-sm font-normal">
                        Specific Locations
                      </FormLabel>
                    </FormItem>
                  </div>

                  {/* Multi-select dropdown - only enabled when "Specific Locations" is selected */}
                  <FormControl>
                    <div className={(!field.value?.includes("SpecificLocations") || field.value?.includes("Any") || field.value?.includes("Remote")) ? "pointer-events-none opacity-50" : ""}>
                      <MultiSelect
                        options={locations.filter(loc => !["Any", "Remote", "SpecificLocations"].includes(loc))}
                        selected={field.value?.includes("SpecificLocations") && !field.value?.includes("Any") && !field.value?.includes("Remote") ? (field.value?.filter(val => !["Any", "Remote", "SpecificLocations"].includes(val)) || []) : []}
                        onChange={(selected) => {
                          if (!field.value?.includes("SpecificLocations") || field.value?.includes("Any") || field.value?.includes("Remote")) return; // No-op unless only "Specific Locations" is selected
                          field.onChange(["SpecificLocations", ...selected]);
                        }}
                        placeholder={
                          field.value?.includes("Any") ? "Any location selected" :
                          field.value?.includes("Remote") ? "Remote work selected" :
                          !field.value?.includes("SpecificLocations") ? "Select 'Specific Locations' to choose cities" :
                          "Search specific cities..."
                        }
                        data-testid="multi-select-locations"
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button
              type="submit"
              className="w-full font-medium"
              disabled={createCandidate.isPending || skillsLoading || locationsLoading}
              data-testid="button-find-matches"
            >
              {createCandidate.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t.processing}
                </>
              ) : (
                t.findMatches
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
