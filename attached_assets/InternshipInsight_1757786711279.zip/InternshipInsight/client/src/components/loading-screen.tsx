import { Card, CardContent } from "@/components/ui/card";
import { Brain, Check, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";

interface LoadingScreenProps {
  language: "en" | "hi";
}

const translations = {
  en: {
    analyzing: "AI is analyzing your profile...",
    description: "Processing 3,270+ internships to find your perfect matches",
    steps: [
      "Analyzing skills compatibility",
      "Matching location preferences", 
      "Generating personalized insights"
    ]
  },
  hi: {
    analyzing: "AI आपकी प्रोफाइल का विश्लेषण कर रहा है...",
    description: "आपके सही मैच खोजने के लिए 3,270+ इंटर्नशिप प्रोसेसिंग",
    steps: [
      "कौशल संगतता का विश्लेषण",
      "स्थान प्राथमिकताओं का मिलान",
      "व्यक्तिगत अंतर्दृष्टि उत्पन्न करना"
    ]
  }
};

export function LoadingScreen({ language }: LoadingScreenProps) {
  const t = translations[language];
  const [currentStep, setCurrentStep] = useState(0);

  useEffect(() => {
    const intervals = [2000, 1500, 1000]; // Time for each step
    let totalTime = 0;

    intervals.forEach((interval, index) => {
      totalTime += interval;
      setTimeout(() => {
        setCurrentStep(index + 1);
      }, totalTime);
    });
  }, []);

  return (
    <div className="animate-fade-in">
      <Card>
        <CardContent className="p-8 text-center">
          <div className="mb-6">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Brain className="h-8 w-8 text-primary animate-pulse" data-testid="loading-icon" />
            </div>
            <h3 className="text-xl font-semibold text-foreground mb-2" data-testid="loading-title">
              {t.analyzing}
            </h3>
            <p className="text-muted-foreground" data-testid="loading-description">
              {t.description}
            </p>
          </div>
          
          <div className="space-y-3">
            {t.steps.map((step, index) => (
              <div 
                key={index}
                className="flex items-center justify-between text-sm"
                data-testid={`loading-step-${index}`}
              >
                <span className={currentStep > index ? "text-foreground" : "text-muted-foreground"}>
                  {step}
                </span>
                {currentStep > index ? (
                  <Check className="h-4 w-4 text-primary" data-testid={`step-complete-${index}`} />
                ) : currentStep === index ? (
                  <Loader2 className="h-4 w-4 text-primary animate-spin" data-testid={`step-loading-${index}`} />
                ) : (
                  <div className="h-4 w-4 rounded-full bg-muted" data-testid={`step-pending-${index}`} />
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
