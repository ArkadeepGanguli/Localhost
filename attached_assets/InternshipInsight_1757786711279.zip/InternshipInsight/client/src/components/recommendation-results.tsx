import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink, Bookmark, Share2, MapPin, Brain, Lightbulb, Code, Loader2 } from "lucide-react";
import type { MatchingResult } from "@/hooks/use-internship-matching";

interface RecommendationResultsProps {
  matches: MatchingResult[];
  allMatches: MatchingResult[];
  language: "en" | "hi";
  onLoadMore?: () => void;
  hasMore?: boolean;
  isLoadingMore?: boolean;
  filterHighMatch: boolean;
  onFilterChange: (filterHigh: boolean) => void;
}

const translations = {
  en: {
    title: "Your Personalized Matches",
    description: "Found internships that match your profile. Here are your top recommendations:",
    topMatch: "Top Match",
    matchScore: "Match Score",
    salaryRange: "Salary Range",
    applyPortal: "Apply on PM Portal",
    save: "Save",
    share: "Share",
    whyPerfectFit: "Why this is a perfect fit for you:",
    whyGreatMatch: "Why this is a great match:",
    goodOpportunity: "A solid opportunity for growth:",
    allMatches: "All Matches",
    remoteAvailable: "Remote Available",
    loadMore: "Load More Matches",
  },
  hi: {
    title: "आपके व्यक्तिगत मैच", 
    description: "आपकी प्रोफाइल से मेल खाने वाली इंटर्नशिप मिलीं। यहाँ आपकी शीर्ष सिफारिशें हैं:",
    topMatch: "टॉप मैच",
    matchScore: "मैच स्कोर",
    salaryRange: "वेतन सीमा",
    applyPortal: "PM पोर्टल पर आवेदन करें",
    save: "सेव करें",
    share: "शेयर करें",
    whyPerfectFit: "यह आपके लिए एक सही फिट क्यों है:",
    whyGreatMatch: "यह एक बेहतरीन मैच क्यों है:",
    goodOpportunity: "विकास का एक ठोस अवसर:",
    allMatches: "सभी मैच",
    remoteAvailable: "रिमोट उपलब्ध",
    loadMore: "और मैच लोड करें",
  }
};

export function RecommendationResults({ matches, allMatches, language, onLoadMore, hasMore = false, isLoadingMore = false, filterHighMatch, onFilterChange }: RecommendationResultsProps) {
  const t = translations[language];
  
  // Matches are already filtered and paginated from parent component
  const filteredMatches = matches;
    
  // Get total counts from all matches for accurate display
  const totalMatches = allMatches.length;
  const totalHighMatches = allMatches.filter(match => match.matchScore >= 90).length;

  const getExplanationIcon = (index: number) => {
    const icons = [Brain, Lightbulb, Code];
    const IconComponent = icons[index % icons.length];
    return <IconComponent className="h-4 w-4 text-white" />;
  };

  const getExplanationColor = (index: number) => {
    const colors = ["bg-accent", "bg-chart-2", "bg-chart-4"];
    return colors[index % colors.length];
  };

  const getExplanationTitle = (index: number) => {
    const titles = [t.whyPerfectFit, t.whyGreatMatch, t.goodOpportunity];
    return titles[index % titles.length];
  };

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold text-foreground mb-2" data-testid="results-title">
          {t.title}
        </h2>
        <p className="text-muted-foreground" data-testid="results-description">
          {t.description}
        </p>
      </div>

      {/* Filter Bar */}
      <Card className="mb-6">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <div className="flex flex-wrap gap-2">
              <Button 
                variant={!filterHighMatch ? "default" : "outline"}
                size="sm" 
                className="rounded-full"
                onClick={() => onFilterChange(false)}
                data-testid="filter-all-matches"
              >
                {t.allMatches}
              </Button>
              <Button 
                variant={filterHighMatch ? "default" : "outline"}
                size="sm" 
                className="rounded-full"
                onClick={() => onFilterChange(true)}
                data-testid="filter-high-match"
              >
                90%+ Match
              </Button>
            </div>
            <div className="text-sm text-muted-foreground">
              Showing {filteredMatches.length} of {filterHighMatch ? totalHighMatches : totalMatches} matches
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recommendation Cards */}
      <div className="space-y-6">
        {filteredMatches.map((match, index) => (
          <Card 
            key={match.internship.id} 
            className="relative overflow-hidden"
            data-testid={`recommendation-card-${index}`}
          >
            {match.isTopMatch && index === 0 && (
              <div className="absolute top-0 right-0 bg-gradient-to-l from-primary to-accent px-4 py-1 text-primary-foreground text-xs font-medium rounded-bl-lg">
                {t.topMatch}
              </div>
            )}
            
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-start gap-6">
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 
                        className="text-xl font-semibold text-foreground mb-1"
                        data-testid={`internship-title-${index}`}
                      >
                        {match.internship.title}
                      </h3>
                      <div className="text-muted-foreground flex items-center">
                        <MapPin className="h-4 w-4 mr-2" />
                        {match.internship.location}
                        {match.locationMatch && match.internship.location.toLowerCase().includes('remote') && (
                          <Badge variant="secondary" className="ml-2">
                            {t.remoteAvailable}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div 
                        className="text-2xl font-bold match-score"
                        data-testid={`match-score-${index}`}
                      >
                        {match.matchScore}%
                      </div>
                      <div className="text-xs text-muted-foreground">{t.matchScore}</div>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    {match.internship.salaryMin && match.internship.salaryMax && (
                      <div className="flex items-center justify-between text-sm mb-2">
                        <span className="text-muted-foreground">{t.salaryRange}</span>
                        <span 
                          className="font-medium text-foreground"
                          data-testid={`salary-range-${index}`}
                        >
                          ₹{match.internship.salaryMin.toLocaleString()} - ₹{match.internship.salaryMax.toLocaleString()}
                        </span>
                      </div>
                    )}
                    <div className="flex flex-wrap gap-2 mb-3">
                      {match.internship.requiredSkills.map((skill) => {
                        const isMatched = match.skillMatches.includes(skill);
                        return (
                          <Badge 
                            key={skill} 
                            variant={isMatched ? "default" : "outline"}
                            className={isMatched 
                              ? "bg-primary/10 text-primary border-primary/20" 
                              : "bg-muted/50 text-muted-foreground border-muted-foreground/20"
                            }
                            data-testid={`skill-${isMatched ? 'match' : 'required'}-${skill.toLowerCase().replace(/\s+/g, '-')}`}
                          >
                            {skill}
                            {isMatched && <span className="ml-1 text-xs">✓</span>}
                          </Badge>
                        );
                      })}
                    </div>
                  </div>

                  {/* AI Generated Explanation */}
                  {match.aiExplanation && (
                    <div className={`${getExplanationColor(index)}/10 border-l-4 ${getExplanationColor(index).replace('bg-', 'border-')} p-4 rounded-r-lg mb-4`}>
                      <div className="flex items-start space-x-3">
                        <div className={`w-8 h-8 ${getExplanationColor(index)} rounded-full flex items-center justify-center flex-shrink-0 mt-1`}>
                          {getExplanationIcon(index)}
                        </div>
                        <div>
                          <h4 className="font-medium text-foreground mb-2">
                            {getExplanationTitle(index)}
                          </h4>
                          <p 
                            className="text-sm text-muted-foreground"
                            data-testid={`ai-explanation-${index}`}
                          >
                            {match.aiExplanation}
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  <div className="flex flex-col sm:flex-row gap-3">
                    <Button 
                      className="flex-1 font-medium" 
                      asChild
                      data-testid={`apply-button-${index}`}
                    >
                      <a 
                        href={match.internship.applyUrl || '#'} 
                        target="_blank" 
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="mr-2 h-4 w-4" />
                        {t.applyPortal}
                      </a>
                    </Button>
                    <Button 
                      variant="outline"
                      data-testid={`save-button-${index}`}
                    >
                      <Bookmark className="mr-2 h-4 w-4" />
                      {t.save}
                    </Button>
                    <Button 
                      variant="outline"
                      data-testid={`share-button-${index}`}
                    >
                      <Share2 className="mr-2 h-4 w-4" />
                      {t.share}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        {/* Load More */}
        {hasMore && onLoadMore && (
          <div className="text-center pt-6">
            <Button 
              variant="outline" 
              className="font-medium"
              onClick={onLoadMore}
              disabled={isLoadingMore}
              data-testid="button-load-more"
            >
              {isLoadingMore ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Loading...
                </>
              ) : (
                t.loadMore
              )}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
