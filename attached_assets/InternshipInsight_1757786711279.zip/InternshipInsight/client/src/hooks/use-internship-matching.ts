import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { CandidateFormData } from "@shared/schema";

export interface MatchingResult {
  internship: {
    id: string;
    title: string;
    location: string;
    sector?: string;
    requiredSkills: string[];
    salaryMin?: number;
    salaryMax?: number;
    description?: string;
    educationRequirement?: string;
    applyUrl?: string;
  };
  matchScore: number;
  skillMatches: string[];
  locationMatch: boolean;
  sectorMatch: boolean;
  educationMatch: boolean;
  aiExplanation?: string;
  isTopMatch: boolean;
}

export interface MatchingResponse {
  matches: MatchingResult[];
  totalMatches: number;
  candidateId: string;
}

export function useSkills() {
  return useQuery<string[]>({
    queryKey: ["/api/skills"],
  });
}

export function useLocations() {
  return useQuery<string[]>({
    queryKey: ["/api/locations"],
  });
}

export function useCreateCandidate() {
  return useMutation({
    mutationFn: async (data: CandidateFormData) => {
      const response = await apiRequest("POST", "/api/candidates", data);
      return response.json();
    },
  });
}

export function useFindMatches() {
  return useMutation({
    mutationFn: async (candidateId: string): Promise<MatchingResponse> => {
      const response = await apiRequest("POST", `/api/matches/${candidateId}`);
      return response.json();
    },
  });
}

export function useTranslate() {
  return useMutation({
    mutationFn: async ({ text, targetLanguage }: { text: string; targetLanguage: "en" | "hi" }) => {
      const response = await apiRequest("POST", "/api/translate", {
        text,
        targetLanguage,
      });
      return response.json();
    },
  });
}
