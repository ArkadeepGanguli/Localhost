import { type CandidateProfile, type InsertCandidateProfile, type Internship, type MatchingResult, type InsertMatchingResult } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Candidate operations
  createCandidateProfile(profile: InsertCandidateProfile): Promise<CandidateProfile>;
  getCandidateProfile(id: string): Promise<CandidateProfile | undefined>;
  getCandidateProfileByEmail(email: string): Promise<CandidateProfile | undefined>;

  // Internship operations
  getInternships(): Promise<Internship[]>;
  getInternshipById(id: string): Promise<Internship | undefined>;
  createInternship(internship: Internship): Promise<Internship>;
  bulkCreateInternships(internships: Internship[]): Promise<void>;

  // Matching results operations
  createMatchingResult(result: InsertMatchingResult): Promise<MatchingResult>;
  getMatchingResultsByCandidateId(candidateId: string): Promise<MatchingResult[]>;
  bulkCreateMatchingResults(results: InsertMatchingResult[]): Promise<void>;

  // Skills and locations
  getUniqueSkills(): Promise<string[]>;
  getUniqueLocations(): Promise<string[]>;
}

export class MemStorage implements IStorage {
  private candidateProfiles: Map<string, CandidateProfile>;
  private internships: Map<string, Internship>;
  private matchingResults: Map<string, MatchingResult>;
  private uniqueSkills: string[];
  private uniqueLocations: string[];

  constructor() {
    this.candidateProfiles = new Map();
    this.internships = new Map();
    this.matchingResults = new Map();
    this.uniqueSkills = [];
    this.uniqueLocations = [];
  }

  async createCandidateProfile(insertProfile: InsertCandidateProfile): Promise<CandidateProfile> {
    const id = randomUUID();
    const profile: CandidateProfile = {
      ...insertProfile,
      id,
      skills: insertProfile.skills || [],
      sectorInterests: insertProfile.sectorInterests || [],
      locationPreferences: insertProfile.locationPreferences || [],
      createdAt: new Date().toISOString(),
    };
    this.candidateProfiles.set(id, profile);
    return profile;
  }

  async getCandidateProfile(id: string): Promise<CandidateProfile | undefined> {
    return this.candidateProfiles.get(id);
  }

  async getCandidateProfileByEmail(email: string): Promise<CandidateProfile | undefined> {
    return Array.from(this.candidateProfiles.values()).find(
      (profile) => profile.email === email,
    );
  }

  async getInternships(): Promise<Internship[]> {
    return Array.from(this.internships.values());
  }

  async getInternshipById(id: string): Promise<Internship | undefined> {
    return this.internships.get(id);
  }

  async createInternship(internship: Internship): Promise<Internship> {
    this.internships.set(internship.id, internship);
    return internship;
  }

  async bulkCreateInternships(internships: Internship[]): Promise<void> {
    for (const internship of internships) {
      this.internships.set(internship.id, internship);
    }
  }

  async createMatchingResult(insertResult: InsertMatchingResult): Promise<MatchingResult> {
    const id = randomUUID();
    const result: MatchingResult = {
      ...insertResult,
      id,
      aiExplanation: insertResult.aiExplanation || null,
      isTopMatch: insertResult.isTopMatch || null,
      createdAt: new Date().toISOString(),
    };
    this.matchingResults.set(id, result);
    return result;
  }

  async getMatchingResultsByCandidateId(candidateId: string): Promise<MatchingResult[]> {
    return Array.from(this.matchingResults.values()).filter(
      (result) => result.candidateId === candidateId,
    );
  }

  async bulkCreateMatchingResults(results: InsertMatchingResult[]): Promise<void> {
    for (const insertResult of results) {
      const id = randomUUID();
      const result: MatchingResult = {
        ...insertResult,
        id,
        aiExplanation: insertResult.aiExplanation || null,
        isTopMatch: insertResult.isTopMatch || null,
        createdAt: new Date().toISOString(),
      };
      this.matchingResults.set(id, result);
    }
  }

  async getUniqueSkills(): Promise<string[]> {
    return this.uniqueSkills;
  }

  async getUniqueLocations(): Promise<string[]> {
    return this.uniqueLocations;
  }

  // Internal methods for data loading
  setUniqueSkills(skills: string[]): void {
    this.uniqueSkills = skills;
  }

  setUniqueLocations(locations: string[]): void {
    this.uniqueLocations = locations;
  }
}

export const storage = new MemStorage();
