import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { candidateFormSchema, type CandidateFormData } from "@shared/schema";
import { CSVLoader } from "./services/csvLoader";
import { MatchingEngine, type MatchResult } from "./services/matchingEngine";
import { summarizeArticle, analyzeSentiment } from "./services/gemini";
import { TranslationService } from "./services/translationService";

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize data on startup
  await CSVLoader.loadSkillsAndLocations();
  await CSVLoader.loadInternships();

  // Get unique skills
  app.get("/api/skills", async (req, res) => {
    try {
      const skills = await storage.getUniqueSkills();
      res.json(skills);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch skills" });
    }
  });

  // Get unique locations
  app.get("/api/locations", async (req, res) => {
    try {
      const locations = await storage.getUniqueLocations();
      res.json(locations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch locations" });
    }
  });

  // Create candidate profile and find matches
  app.post("/api/candidates", async (req, res) => {
    try {
      const validatedData = candidateFormSchema.parse(req.body);
      
      // Check if candidate already exists
      const existingCandidate = await storage.getCandidateProfileByEmail(validatedData.email);
      
      let candidate;
      if (existingCandidate) {
        candidate = existingCandidate;
      } else {
        candidate = await storage.createCandidateProfile(validatedData);
      }
      
      res.json({ 
        candidate,
        message: "Profile created successfully" 
      });
    } catch (error) {
      console.error("Error creating candidate:", error);
      res.status(400).json({ 
        message: error instanceof Error ? error.message : "Failed to create candidate profile" 
      });
    }
  });

  // Find internship matches
  app.post("/api/matches/:candidateId", async (req, res) => {
    try {
      const { candidateId } = req.params;
      const candidate = await storage.getCandidateProfile(candidateId);
      
      if (!candidate) {
        return res.status(404).json({ message: "Candidate not found" });
      }

      // Get all internships
      const internships = await storage.getInternships();
      
      // Filter and rank internships (lower threshold to show more results)
      const matches = MatchingEngine.filterAndRankInternships(candidate, internships, 10);
      
      // Get top matches (fast response without AI)
      const topMatches = matches.slice(0, 5);
      
      // Generate simple, fast explanations based on matching criteria
      const aiExplanations = topMatches.map((match) => {
        const explanations = [];
        
        if (match.skillMatches.length > 0) {
          explanations.push(`Strong skill match with ${match.skillMatches.length} of your skills: ${match.skillMatches.slice(0, 2).join(', ')}.`);
        }
        
        if (match.locationMatch) {
          explanations.push(`Location aligns with your preferences.`);
        }
        
        if (match.sectorMatch) {
          explanations.push(`Perfect sector match for your interests.`);
        }
        
        if (match.educationMatch) {
          explanations.push(`Your education level meets the requirements.`);
        }
        
        return explanations.length > 0 
          ? explanations.join(' ') 
          : "This internship offers great learning opportunities for your career growth.";
      });
      
      // Store matching results
      const matchingResults = MatchingEngine.createMatchingResults(
        candidateId,
        topMatches,
        aiExplanations
      );
      
      await storage.bulkCreateMatchingResults(matchingResults);
      
      // Prepare response
      const response = topMatches.map((match, index) => ({
        internship: match.internship,
        matchScore: match.score,
        skillMatches: match.skillMatches,
        locationMatch: match.locationMatch,
        sectorMatch: match.sectorMatch,
        educationMatch: match.educationMatch,
        aiExplanation: aiExplanations[index],
        isTopMatch: index < 3,
      }));
      
      res.json({
        matches: response,
        totalMatches: matches.length,
        candidateId,
      });
    } catch (error) {
      console.error("Error finding matches:", error);
      res.status(500).json({ 
        message: "Failed to find matches" 
      });
    }
  });

  // Get candidate's previous matches
  app.get("/api/matches/:candidateId", async (req, res) => {
    try {
      const { candidateId } = req.params;
      const matchingResults = await storage.getMatchingResultsByCandidateId(candidateId);
      
      // Get internship details for each match
      const matches = await Promise.all(
        matchingResults.map(async (result) => {
          const internship = await storage.getInternshipById(result.internshipId);
          return {
            ...result,
            internship,
          };
        })
      );
      
      res.json(matches);
    } catch (error) {
      console.error("Error fetching matches:", error);
      res.status(500).json({ message: "Failed to fetch matches" });
    }
  });

  // Translation endpoint
  app.post("/api/translate", async (req, res) => {
    try {
      const { text, targetLanguage } = req.body;
      
      if (!text || !targetLanguage) {
        return res.status(400).json({ message: "Text and target language are required" });
      }
      
      const translatedText = TranslationService.translateText(text, targetLanguage);
      
      res.json({ 
        originalText: text,
        translatedText,
        targetLanguage 
      });
    } catch (error) {
      console.error("Error translating text:", error);
      res.status(500).json({ message: "Failed to translate text" });
    }
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "healthy",
      timestamp: new Date().toISOString(),
      environment: process.env.NODE_ENV || "development"
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}
