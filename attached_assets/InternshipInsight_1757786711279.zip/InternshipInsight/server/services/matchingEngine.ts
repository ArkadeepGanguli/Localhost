import { type CandidateProfile, type Internship, type InsertMatchingResult } from "@shared/schema";

export interface MatchingCriteria {
  educationWeight: number;
  skillsWeight: number;
  locationWeight: number;
  sectorWeight: number;
}

export interface MatchResult {
  internship: Internship;
  score: number;
  skillMatches: string[];
  locationMatch: boolean;
  sectorMatch: boolean;
  educationMatch: boolean;
}

export class MatchingEngine {
  private static readonly DEFAULT_CRITERIA: MatchingCriteria = {
    educationWeight: 0.2,
    skillsWeight: 0.4,
    locationWeight: 0.25,
    sectorWeight: 0.15,
  };

  static calculateMatch(
    candidate: CandidateProfile,
    internship: Internship,
    criteria: MatchingCriteria = this.DEFAULT_CRITERIA
  ): MatchResult {
    // Education matching
    const educationMatch = this.matchEducation(candidate.educationLevel, internship.educationRequirement);
    const educationScore = educationMatch ? 100 : 0;

    // Skills matching
    const skillMatches = this.matchSkills(candidate.skills, internship.requiredSkills);
    const skillsScore = internship.requiredSkills.length > 0 
      ? (skillMatches.length / internship.requiredSkills.length) * 100 
      : 50;

    // Location matching
    const locationMatch = this.matchLocation(candidate.locationPreferences, internship.location);
    const locationScore = locationMatch ? 100 : 0;

    // Sector matching
    const sectorMatch = this.matchSector(candidate.sectorInterests, internship.sector);
    const sectorScore = sectorMatch ? 100 : 0;

    // Calculate weighted total score
    const totalScore = Math.round(
      (educationScore * criteria.educationWeight) +
      (skillsScore * criteria.skillsWeight) +
      (locationScore * criteria.locationWeight) +
      (sectorScore * criteria.sectorWeight)
    );

    return {
      internship,
      score: Math.min(totalScore, 100),
      skillMatches,
      locationMatch,
      sectorMatch,
      educationMatch,
    };
  }

  static filterAndRankInternships(
    candidate: CandidateProfile,
    internships: Internship[],
    minScore: number = 50
  ): MatchResult[] {
    const matches = internships
      .map(internship => this.calculateMatch(candidate, internship))
      .filter(match => match.score >= minScore)
      .sort((a, b) => b.score - a.score);

    return matches;
  }

  private static matchEducation(candidateLevel: string, requiredLevel?: string | null): boolean {
    if (!requiredLevel) return true;

    const educationLevels = {
      'high-school': 1,
      'diploma': 2,
      'bachelors': 3,
      'masters': 4,
      'phd': 5,
    };

    const candidateRank = educationLevels[candidateLevel as keyof typeof educationLevels] || 0;
    const requiredRank = educationLevels[requiredLevel as keyof typeof educationLevels] || 0;

    return candidateRank >= requiredRank;
  }

  private static matchSkills(candidateSkills: string[], requiredSkills: string[]): string[] {
    return requiredSkills.filter(skill => 
      candidateSkills.some(candidateSkill => 
        candidateSkill.toLowerCase().includes(skill.toLowerCase()) ||
        skill.toLowerCase().includes(candidateSkill.toLowerCase())
      )
    );
  }

  private static matchLocation(candidatePreferences: string[], internshipLocation: string): boolean {
    if (candidatePreferences.includes('Remote') || internshipLocation.toLowerCase().includes('remote')) {
      return true;
    }

    return candidatePreferences.some(preference => 
      preference.toLowerCase() === internshipLocation.toLowerCase() ||
      internshipLocation.toLowerCase().includes(preference.toLowerCase())
    );
  }

  private static matchSector(candidateInterests: string[], internshipSector?: string | null): boolean {
    if (!internshipSector) return true;

    return candidateInterests.some(interest => 
      interest.toLowerCase() === internshipSector.toLowerCase() ||
      internshipSector.toLowerCase().includes(interest.toLowerCase())
    );
  }

  static createMatchingResults(
    candidateId: string,
    matches: MatchResult[],
    aiExplanations: string[]
  ): InsertMatchingResult[] {
    return matches.map((match, index) => ({
      candidateId,
      internshipId: match.internship.id,
      matchScore: match.score,
      aiExplanation: aiExplanations[index] || '',
      isTopMatch: index < 3, // Top 3 matches
    }));
  }
}
