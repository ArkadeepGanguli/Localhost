import { GoogleGenAI } from "@google/genai";

// This API key is from Gemini Developer API Key, not vertex AI API Key
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function summarizeArticle(text: string): Promise<string> {
    const prompt = `Please summarize the following text concisely while maintaining key points:\n\n${text}`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
    });

    return response.text || "Something went wrong";
}

export interface Sentiment {
    rating: number;
    confidence: number;
}

export async function analyzeSentiment(text: string): Promise<Sentiment> {
    try {
        const systemPrompt = `You are a sentiment analysis expert. 
Analyze the sentiment of the text and provide a rating
from 1 to 5 stars and a confidence score between 0 and 1.
Respond with JSON in this format: 
{'rating': number, 'confidence': number}`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            config: {
                systemInstruction: systemPrompt,
                responseMimeType: "application/json",
                responseSchema: {
                    type: "object",
                    properties: {
                        rating: { type: "number" },
                        confidence: { type: "number" },
                    },
                    required: ["rating", "confidence"],
                },
            },
            contents: text,
        });

        const rawJson = response.text;

        console.log(`Raw JSON: ${rawJson}`);

        if (rawJson) {
            const data: Sentiment = JSON.parse(rawJson);
            return data;
        } else {
            throw new Error("Empty response from model");
        }
    } catch (error) {
        throw new Error(`Failed to analyze sentiment: ${error}`);
    }
}

export async function generateInternshipExplanation(
    candidateProfile: {
        skills: string[];
        educationLevel: string;
        locationPreferences: string[];
        sectorInterests: string[];
    },
    internship: {
        title: string;
        location: string;
        sector?: string;
        requiredSkills: string[];
        salaryMin?: number;
        salaryMax?: number;
    },
    matchScore: number,
    skillMatches: string[],
    locationMatch: boolean,
    sectorMatch: boolean
): Promise<string> {
    try {
        const prompt = `Generate a brief, personalized explanation (2-3 sentences) for why this internship is a good fit for the candidate. Be encouraging and specific about the match reasons.

Candidate Profile:
- Skills: ${candidateProfile.skills.join(', ')}
- Education: ${candidateProfile.educationLevel}
- Location Preferences: ${candidateProfile.locationPreferences.join(', ')}
- Sector Interests: ${candidateProfile.sectorInterests.join(', ')}

Internship Details:
- Title: ${internship.title}
- Location: ${internship.location}
- Sector: ${internship.sector || 'Not specified'}
- Required Skills: ${internship.requiredSkills.join(', ')}
- Salary Range: ${internship.salaryMin && internship.salaryMax ? `₹${internship.salaryMin.toLocaleString()} - ₹${internship.salaryMax.toLocaleString()}` : 'Not specified'}

Match Analysis:
- Overall Match Score: ${matchScore}%
- Matching Skills: ${skillMatches.join(', ') || 'None directly matched'}
- Location Match: ${locationMatch ? 'Yes' : 'No'}
- Sector Match: ${sectorMatch ? 'Yes' : 'No'}

Guidelines:
- Focus on the strongest match aspects (skills, location, sector, growth opportunities)
- Mention specific skills that align
- Highlight learning and career growth potential
- Keep it concise, positive, and actionable
- If location matches or remote work is available, mention the convenience
- If salary is competitive, mention the financial benefits

Example output style: "Your Python and machine learning expertise perfectly align with this role's requirements. The remote work option matches your location preferences, and this position offers excellent opportunities to advance your skills in AI development while earning competitive compensation."`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
        });

        const explanation = response.text?.trim();
        
        if (!explanation) {
            // Fallback explanation based on match data
            return generateFallbackExplanation(candidateProfile, internship, matchScore, skillMatches, locationMatch, sectorMatch);
        }

        return explanation;
    } catch (error) {
        console.error('Error generating AI explanation:', error);
        // Return fallback explanation on error
        return generateFallbackExplanation(candidateProfile, internship, matchScore, skillMatches, locationMatch, sectorMatch);
    }
}

function generateFallbackExplanation(
    candidateProfile: {
        skills: string[];
        educationLevel: string;
        locationPreferences: string[];
        sectorInterests: string[];
    },
    internship: {
        title: string;
        location: string;
        sector?: string;
        requiredSkills: string[];
    },
    matchScore: number,
    skillMatches: string[],
    locationMatch: boolean,
    sectorMatch: boolean
): string {
    const reasons = [];
    
    if (skillMatches.length > 0) {
        reasons.push(`Your expertise in ${skillMatches.slice(0, 2).join(' and ')} aligns well with this role's requirements`);
    }
    
    if (locationMatch) {
        reasons.push(`the location matches your preferences`);
    }
    
    if (sectorMatch && internship.sector) {
        reasons.push(`this opportunity is in your preferred ${internship.sector.toLowerCase()} sector`);
    }
    
    if (reasons.length === 0) {
        return `This ${internship.title} position offers valuable experience and learning opportunities that can help advance your career goals.`;
    }
    
    const reasonText = reasons.length > 1 
        ? reasons.slice(0, -1).join(', ') + ', and ' + reasons[reasons.length - 1]
        : reasons[0];
    
    return `This internship is a great fit because ${reasonText}. It provides excellent opportunities for professional growth and skill development.`;
}

export async function rankInternships(
    candidateProfile: {
        skills: string[];
        educationLevel: string;
        locationPreferences: string[];
        sectorInterests: string[];
    },
    internships: Array<{
        id: string;
        title: string;
        location: string;
        sector?: string;
        requiredSkills: string[];
        salaryMin?: number;
        salaryMax?: number;
        description?: string;
    }>,
    existingScores: number[]
): Promise<number[]> {
    try {
        const prompt = `You are an AI career counselor helping to rank internship opportunities for a candidate. 
        
Candidate Profile:
- Skills: ${candidateProfile.skills.join(', ')}
- Education: ${candidateProfile.educationLevel}
- Location Preferences: ${candidateProfile.locationPreferences.join(', ')}
- Sector Interests: ${candidateProfile.sectorInterests.join(', ')}

Internships to rank (with current rule-based scores):
${internships.map((internship, index) => `
${index + 1}. ${internship.title} (Current Score: ${existingScores[index]}%)
   Location: ${internship.location}
   Sector: ${internship.sector || 'Not specified'}
   Required Skills: ${internship.requiredSkills.join(', ')}
   Salary: ${internship.salaryMin && internship.salaryMax ? `₹${internship.salaryMin.toLocaleString()} - ₹${internship.salaryMax.toLocaleString()}` : 'Not specified'}
`).join('')}

Please provide adjusted scores (0-100) for each internship considering:
1. Skills alignment and transferability
2. Career growth potential
3. Industry trends and future prospects
4. Learning opportunities
5. Overall fit with candidate's profile

Respond with only a JSON array of numbers representing the adjusted scores for each internship in order.
Example: [95, 87, 82, 76, 71]`;

        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            config: {
                responseMimeType: "application/json",
            },
            contents: prompt,
        });

        const rawJson = response.text;
        
        if (rawJson) {
            const adjustedScores: number[] = JSON.parse(rawJson);
            
            // Validate and sanitize scores
            const validScores = adjustedScores.map((score, index) => {
                const numScore = Number(score);
                if (isNaN(numScore) || numScore < 0 || numScore > 100) {
                    return existingScores[index]; // Fallback to original score
                }
                return Math.round(numScore);
            });
            
            return validScores;
        }
        
        return existingScores; // Fallback to original scores
    } catch (error) {
        console.error('Error ranking internships with AI:', error);
        return existingScores; // Fallback to original scores
    }
}
