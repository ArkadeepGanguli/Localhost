import * as fs from "fs";
import * as path from "path";
import { type Internship } from "@shared/schema";
import { storage } from "../storage";

interface CSVRow {
  [key: string]: string;
}

export class CSVLoader {
  private static parseCSV(content: string): CSVRow[] {
    const lines = content.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim());
    
    return lines.slice(1).map(line => {
      const values = line.split(',').map(v => v.trim());
      const row: CSVRow = {};
      headers.forEach((header, index) => {
        row[header] = values[index] || '';
      });
      return row;
    });
  }

  static async loadSkillsAndLocations(): Promise<void> {
    try {
      // Load skills
      const skillsPath = path.resolve(process.cwd(), 'attached_assets', 'unique_skills_1757776052706.csv');
      const skillsContent = fs.readFileSync(skillsPath, 'utf-8');
      const skillsRows = this.parseCSV(skillsContent);
      const skills = skillsRows.map(row => row.skill).filter(skill => skill && skill.trim() !== '');
      storage.setUniqueSkills(skills);

      // Load locations
      const locationsPath = path.resolve(process.cwd(), 'attached_assets', 'unique_locations_1757776052705.csv');
      const locationsContent = fs.readFileSync(locationsPath, 'utf-8');
      const locationsRows = this.parseCSV(locationsContent);
      const locations = locationsRows.map(row => row.location).filter(location => location && location.trim() !== '');
      storage.setUniqueLocations(locations);

      console.log(`Loaded ${skills.length} skills and ${locations.length} locations`);
    } catch (error) {
      console.error('Error loading CSV files:', error);
      // Set default data if files are not found
      storage.setUniqueSkills([
        'Python', 'JavaScript', 'Machine Learning', 'Data Science',
        'Digital Marketing', 'Content Writing', 'React', 'Node.js'
      ]);
      storage.setUniqueLocations([
        'Remote', 'Mumbai', 'Delhi', 'Bangalore', 'Pune', 'Hyderabad'
      ]);
    }
  }

  static async loadInternships(): Promise<void> {
    try {
      // Note: The internships_filtered.csv file is mentioned but not provided
      // For now, we'll create sample internships based on the CSV data structure
      const sampleInternships: Internship[] = [
        {
          id: "ml-intern-hyderabad-001",
          title: "Machine Learning Intern",
          location: "Hyderabad",
          sector: "Technology",
          requiredSkills: ["Python", "Machine Learning", "Data Science", "AI"],
          salaryMin: 5000,
          salaryMax: 10000,
          description: "Work on cutting-edge ML projects with real-world applications",
          educationRequirement: "bachelors",
          applyUrl: "https://pminternship.mca.gov.in/apply/ml-intern-001"
        },
        {
          id: "digital-marketing-mumbai-002",
          title: "Digital Marketing Specialist",
          location: "Mumbai",
          sector: "Marketing",
          requiredSkills: ["Digital Marketing", "SEO", "Content Writing", "Social Media Marketing"],
          salaryMin: 8500,
          salaryMax: 12000,
          description: "Drive digital marketing campaigns and grow online presence",
          educationRequirement: "diploma",
          applyUrl: "https://pminternship.mca.gov.in/apply/digital-marketing-002"
        },
        {
          id: "software-dev-bangalore-003",
          title: "Software Development Intern",
          location: "Bangalore",
          sector: "Technology",
          requiredSkills: ["Python", "JavaScript", "React", "Backend"],
          salaryMin: 10000,
          salaryMax: 15000,
          description: "Build modern web applications using latest technologies",
          educationRequirement: "bachelors",
          applyUrl: "https://pminternship.mca.gov.in/apply/software-dev-003"
        },
        {
          id: "ui-ux-pune-004",
          title: "UI/UX Design Intern",
          location: "Pune",
          sector: "Design",
          requiredSkills: ["UI Design", "UX Design", "Figma", "Adobe Creative Suite"],
          salaryMin: 7000,
          salaryMax: 11000,
          description: "Create intuitive user experiences for digital products",
          educationRequirement: "diploma",
          applyUrl: "https://pminternship.mca.gov.in/apply/ui-ux-004"
        },
        {
          id: "data-analyst-remote-005",
          title: "Data Analyst Intern",
          location: "Remote",
          sector: "Technology",
          requiredSkills: ["Data Analysis", "Python", "SQL", "Statistics"],
          salaryMin: 6000,
          salaryMax: 9000,
          description: "Analyze business data to drive insights and decisions",
          educationRequirement: "bachelors",
          applyUrl: "https://pminternship.mca.gov.in/apply/data-analyst-005"
        }
      ];

      await storage.bulkCreateInternships(sampleInternships);
      console.log(`Loaded ${sampleInternships.length} internships`);
    } catch (error) {
      console.error('Error loading internships:', error);
    }
  }
}
