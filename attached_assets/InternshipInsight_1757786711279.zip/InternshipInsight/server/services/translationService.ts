export interface Translation {
  [key: string]: string;
}

export interface Translations {
  en: Translation;
  hi: Translation;
}

const translations: Translations = {
  en: {
    // Header
    'header-subtitle': 'Smart Matching Platform',
    'step-1': 'Step 1 of 3',
    'profile-setup': 'Profile Setup',
    
    // Form labels
    'profile-title': 'Tell us about yourself',
    'profile-subtitle': 'Help us find the perfect internship opportunities for you',
    'full-name': 'Full Name',
    'email': 'Email Address',
    'education-level': 'Education Level',
    'select-education': 'Select your education level',
    'skills': 'Skills & Expertise',
    'sector-interests': 'Sector Interests',
    'location-preferences': 'Location Preferences',
    'save-draft': 'Save Draft',
    'find-matches': 'Find My Matches',
    
    // AI processing
    'ai-analyzing': 'AI is analyzing your profile...',
    'ai-analyzing-desc': 'Processing 3,270+ internships to find your perfect matches',
    'analyzing-skills': 'Analyzing skills compatibility',
    'matching-locations': 'Matching location preferences',
    'generating-insights': 'Generating personalized insights',
    
    // Results
    'your-matches': 'Your Personalized Matches',
    'matches-desc': 'Found internships that match your profile. Here are your top recommendations:',
    'why-perfect-fit': 'Why this is a perfect fit for you:',
    'why-great-match': 'Why this is a great match:',
    'good-opportunity': 'A solid opportunity for growth:',
  },
  hi: {
    // Header
    'header-subtitle': 'स्मार्ट मैचिंग प्लेटफॉर्म',
    'step-1': 'चरण 1 का 3',
    'profile-setup': 'प्रोफाइल सेटअप',
    
    // Form labels
    'profile-title': 'अपने बारे में बताएं',
    'profile-subtitle': 'हमें आपके लिए सही इंटर्नशिप अवसर खोजने में मदद करें',
    'full-name': 'पूरा नाम',
    'email': 'ईमेल पता',
    'education-level': 'शिक्षा स्तर',
    'select-education': 'अपना शिक्षा स्तर चुनें',
    'skills': 'कौशल और विशेषज्ञता',
    'sector-interests': 'क्षेत्र रुचियां',
    'location-preferences': 'स्थान प्राथमिकताएं',
    'save-draft': 'ड्राफ्ट सेव करें',
    'find-matches': 'मेरे मैच खोजें',
    
    // AI processing
    'ai-analyzing': 'AI आपकी प्रोफाइल का विश्लेषण कर रहा है...',
    'ai-analyzing-desc': 'आपके सही मैच खोजने के लिए 3,270+ इंटर्नशिप प्रोसेसिंग',
    'analyzing-skills': 'कौशल संगतता का विश्लेषण',
    'matching-locations': 'स्थान प्राथमिकताओं का मिलान',
    'generating-insights': 'व्यक्तिगत अंतर्दृष्टि उत्पन्न करना',
    
    // Results
    'your-matches': 'आपके व्यक्तिगत मैच',
    'matches-desc': 'आपकी प्रोफाइल से मेल खाने वाली इंटर्नशिप मिलीं। यहाँ आपकी शीर्ष सिफारिशें हैं:',
    'why-perfect-fit': 'यह आपके लिए एक सही फिट क्यों है:',
    'why-great-match': 'यह एक बेहतरीन मैच क्यों है:',
    'good-opportunity': 'विकास का एक ठोस अवसर:',
  }
};

export class TranslationService {
  static translate(key: string, language: 'en' | 'hi' = 'en'): string {
    return translations[language][key] || translations.en[key] || key;
  }

  static translateText(text: string, targetLanguage: 'hi' | 'en'): string {
    // For production, this would integrate with Google Translate API or similar
    // For now, return the original text
    return text;
  }

  static getSupportedLanguages(): string[] {
    return ['en', 'hi'];
  }
}
