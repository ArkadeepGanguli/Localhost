import { sql } from "drizzle-orm";
import { pgTable, text, varchar, jsonb, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const candidateProfiles = pgTable("candidate_profiles", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fullName: text("full_name").notNull(),
  email: text("email").notNull().unique(),
  educationLevel: text("education_level").notNull(),
  skills: jsonb("skills").$type<string[]>().notNull().default([]),
  sectorInterests: jsonb("sector_interests").$type<string[]>().notNull().default([]),
  locationPreferences: jsonb("location_preferences").$type<string[]>().notNull().default([]),
  languagePreference: text("language_preference").notNull().default("en"),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

export const internships = pgTable("internships", {
  id: varchar("id").primaryKey(),
  title: text("title").notNull(),
  location: text("location").notNull(),
  sector: text("sector"),
  requiredSkills: jsonb("required_skills").$type<string[]>().notNull().default([]),
  salaryMin: integer("salary_min"),
  salaryMax: integer("salary_max"),
  description: text("description"),
  educationRequirement: text("education_requirement"),
  applyUrl: text("apply_url"),
});

export const matchingResults = pgTable("matching_results", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  candidateId: varchar("candidate_id").notNull(),
  internshipId: varchar("internship_id").notNull(),
  matchScore: integer("match_score").notNull(),
  aiExplanation: text("ai_explanation"),
  isTopMatch: boolean("is_top_match").default(false),
  createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
});

// Insert schemas
export const insertCandidateProfileSchema = createInsertSchema(candidateProfiles).omit({
  id: true,
  createdAt: true,
});

export const insertInternshipSchema = createInsertSchema(internships);

export const insertMatchingResultSchema = createInsertSchema(matchingResults).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertCandidateProfile = z.infer<typeof insertCandidateProfileSchema>;
export type CandidateProfile = typeof candidateProfiles.$inferSelect;
export type Internship = typeof internships.$inferSelect;
export type MatchingResult = typeof matchingResults.$inferSelect;
export type InsertMatchingResult = z.infer<typeof insertMatchingResultSchema>;

// Form schemas with validation
export const candidateFormSchema = insertCandidateProfileSchema.extend({
  fullName: z.string().min(2, "Full name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  educationLevel: z.enum(["high-school", "diploma", "bachelors", "masters", "phd"]),
  skills: z.array(z.string()).min(1, "Please select at least one skill"),
  sectorInterests: z.array(z.string()).min(1, "Please select at least one sector"),
  locationPreferences: z.array(z.string()).min(1, "Please select at least one location"),
  languagePreference: z.enum(["en", "hi"]).default("en"),
});

export type CandidateFormData = z.infer<typeof candidateFormSchema>;
